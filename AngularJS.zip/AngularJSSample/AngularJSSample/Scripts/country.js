﻿/// <reference path="angular.js" />

var app = angular.module("countryModule", []);
    app.controller("CountryController", function ($scope, $http, $location, $anchorScroll) {
        $http.post("CountryService.asmx/GetData")
            .then(function (response) {
                $scope.countries = response.data;
            })

        $scope.scrollTo = function (country) {
            $location.hash(country);
            $anchorScroll();
        }
    })