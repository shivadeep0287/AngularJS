﻿/// <reference path="angular.intellisense.js" />
/// <reference path="angular.js" />

var app = angular.module("route", ["ui.router"])
    .config(function ($stateProvider, $urlMatcherFactoryProvider, $urlRouterProvider, $locationProvider) {
        $urlRouterProvider.otherwise("home");
        $urlMatcherFactoryProvider.caseInsensitive(true);
        $stateProvider
            .state("home", {
                url: "/home",
                templateUrl: "Templates/home.html",
                controller: "homeController",
                controllerAs: "homeCtrl",
                data: {
                    customData1: "Home controller Custom data 1",
                    customData2: "Home controller Custom data 2"
                }
            })
            .state("courses", {
                url:"/courses",
                templateUrl: "Templates/courses.html",
                controller: "coursesController",
                controllerAs: "coursesCtrl",
                data: {
                    customData1: "Course controller Custom data 1",
                    customData2: "Course controller Custom data 2"
                }
            })
            .state("employees", {
                url: "/employees",
                templateUrl: "Templates/employees.html",
                controller: "empController",
                controllerAs: "empCtrl",
                resolve: {
                    employeeList: function ($http) {
                        return $http.get("EmployeeService.asmx/GetAllEmployee")
                            .then(function (response) {
                                return response.data;
                            })
                    }
                }
            })
            .state("employeeDetails", {
                url:"/employeeDetails/:id",
                templateUrl: "Templates/employeeDetails.html",
                controller: "employeeDetailsController",
                controllerAs: "employeeDetailsCtrl"
            })
            .state("empSearch", {
                url:"/empSearch/:name",
                templateUrl: "Templates/empSearch.html",
                controller: "empSearchController",
                controllerAs: "empSearchCtrl"
            })
            //.otherwise({
            //    redirectTo: "/home"
            //})
        //$locationProvider.html5mode(true);

    }).controller("homeController", function ($rootScope, $state) {
        $rootScope.message = "Web Home Page";

        this.homeCustomData1 = $state.current.data.customData1;
        this.homeCustomData2 = $state.current.data.customData2;

        this.courseCustomData1 = $state.get("courses").data.customData1;
        this.courseCustomData2 = $state.get("courses").data.customData2;
    })
    .controller("coursesController", function () {
        this.courses = ["C#", "ASP.Net", "Angular JS", "SQL"];
    })
    .controller("empController", function ($http, employeeList, $state, $location, $scope) {
        var vm = this;
        vm.reloadData = function () {
            $state.reload();
        }
        vm.searchEmp = function () {
               $state.go("empSearch", { name: vm.name });
        }

        $scope.$on("$locationChangeStart", function (event, next, current) {
            if (!confirm("Are you sure you want to navigate away from this page to " + next)) {
                event.preventDefault();
            }
        })

        vm.employees = employeeList;

    })
    .controller("employeeDetailsController", function ($http, $stateParams) {
        var vm = this;
        $http({
            url: "EmployeeService.asmx/GetEmployee",
            params: { id: $stateParams.id },
            method: "get",
        })
            .then(function (response) {
                vm.employee = response.data;
            })
    })
    .controller("empSearchController", function ($http, $stateParams) {
        var vm = this;
        if ($stateParams.name) {
            $http({
                url: "EmployeeService.asmx/GetEmployeeByName",
                params: { name: $stateParams.name },
                method: "get",
            })
                .then(function (response) {
                    vm.employees = response.data;
                })
        }
        else {
            $http.get("EmployeeService.asmx/GetAllEmployee")
                .then(function (response) {
                    vm.employees = response.data;
                })
        }
    })

app.config(['$qProvider', function ($qProvider) {
    $qProvider.errorOnUnhandledRejections(false);

}])



//var app = angular.module("route", ["ngRoute"])
//    .config(function ($routeProvider, $locationProvider) {
//        $locationProvider.hashPrefix('');
//        $routeProvider.caseInsensitiveMatch = true;
//        $routeProvider
//            .when("/home", {
//                templateUrl: "Templates/home.html",
//                controller: "homeController",
//                controllerAs: "homeCtrl"
//            })
//            .when("/courses", {
//                templateUrl: "Templates/courses.html",
//                controller: "coursesController",
//                controllerAs: "coursesCtrl"
//            })
//            .when("/employees", {
//                templateUrl: "Templates/employees.html",
//                controller: "empController",
//                controllerAs: "empCtrl",
//                resolve: {
//                    employeeList: function ($http) {
//                       return $http.get("EmployeeService.asmx/GetAllEmployee")
//                            .then(function (response) {
//                               return response.data;
//                            })
//                    }
//                }
//            })
//            .when("/employeeDetails/:id", {
//                templateUrl: "Templates/employeeDetails.html",
//                controller: "employeeDetailsController",
//                controllerAs: "employeeDetailsCtrl"
//            })
//            .when("/empSearch/:name?", {
//                templateUrl: "Templates/empSearch.html",
//                controller: "empSearchController",
//                controllerAs: "empSearchCtrl"
//            })
//            .otherwise({
//                redirectTo: "/home"
//            })
//        //$locationProvider.html5mode(true);

//    }).controller("homeController", function ( $rootScope) {
//        $rootScope.message = "Web Home Page";
//    })
//    .controller("coursesController", function () {
//        this.courses = ["C#", "ASP.Net", "Angular JS", "SQL"];
//    })
//    .controller("empController", function ($http, employeeList, $route,$location,$scope) {
//        var vm = this;
//        vm.reloadData = function () {
//            $route.reload();
//        }
//        vm.searchEmp = function () {
//            if (vm.name) {
//                $location.url("/empSearch/" + vm.name)
//            }
//            else {
//                $location.url("/empSearch");
//            }
            
//        }
//        $scope.$on("$locationChangeStart", function (event,next,current) {
//            if (!confirm("Are you sure you want to navigate away from this page to " + next)) {
//                event.preventDefault();
//            }
//        })

//        vm.employees = employeeList;
        
//    })
//    .controller("employeeDetailsController", function ( $http, $routeParams) {
//        var vm = this;
//        $http({
//            url: "EmployeeService.asmx/GetEmployee",
//            params: { id: $routeParams.id },
//            method: "get",
//        })
//            .then(function (response) {
//                vm.employee = response.data;
//            })
//    })
//    .controller("empSearchController", function ($http, $routeParams) {
//        var vm = this;
//        if ($routeParams.name) {
//            $http({
//                url: "EmployeeService.asmx/GetEmployeeByName",
//                params: { name: $routeParams.name },
//                method: "get",
//            })
//                .then(function (response) {
//                    vm.employees = response.data;
//                })
//        }
//        else {
//            $http.get("EmployeeService.asmx/GetAllEmployee")
//                .then(function (response) {
//                    vm.employees = response.data;
//                })
//        }
//    })

//app.config(['$qProvider', function ($qProvider) {
//    $qProvider.errorOnUnhandledRejections(false);

//}])
