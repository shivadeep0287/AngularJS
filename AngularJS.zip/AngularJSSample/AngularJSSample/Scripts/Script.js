﻿/// <reference path="angular.js" />

var myApp = angular.module("myModule", []);

myApp.controller("myController", function ($scope, $http, $log, stringservice,$location,$anchorScroll) {
    var employee = {
        firstName: "Shivadeep",
        lastName: "MS",
        gender: "Male"
    };

    $scope.employee = employee;

    $scope.scrollTo = function (scrollLocation) {
        $location.hash(scrollLocation);
        $anchorScroll.yOffset = 20;
        $anchorScroll();
    }

    var successcallback = function (response) {
        $scope.employees = response.data;
        $log.info(response);
    }

    var errorcallback = function (reason) {
        $scope.error = reason.data;
        $log.info(reason);
    }

    $http.get("EmployeeService.asmx/GetAllEmployee")
        .then(successcallback, errorcallback);

    $scope.transformString = function (input) {
        $scope.output = stringservice.ProcessString(input)
    }

    var countries = [
        {
            name :"US",
            cities :[
                { name: "LA" },
                { name: "Chicago" },
                { name: "Houston" }
            ]
        },
        {
            name : "UK",
            cities :[
                { name: "London" },
                { name: "Brimigham" },
                { name: "Manchestar" }
            ]
        },
        {
            name : "India",
            cities :[
                { name: "Bangalore" },
                { name: "Delhi" },
                { name: "Punjab" }
            ]
        }
    ];

    $scope.countries = countries;

    var technologies = [
        { name: "C#", likes: 0, dislikes: 0 },
        { name: "ASP.Net", likes: 0, dislikes: 0 },
        { name: "SQL", likes: 0, dislikes: 0 },
        { name: "Angular JS", likes: 0, dislikes: 0 },
    ];

    $scope.technologies = technologies;

    $scope.incrementLikes = function (technology) {
        technology.likes++;
    }

    $scope.incrementDislikes = function (technology) {
        technology.dislikes++;
    }

    var employeesToFilter = [
        { name: "Ben", dateofbirth: new Date("November 23,1980"), gender: 1, salary: 50000.788 },
        { name: "Sara", dateofbirth: new Date("May 05,1985"), gender: 2, salary: 68000 },
        { name: "Mark", dateofbirth: new Date("August 15,1984"), gender: 1, salary: 57000 },
        { name: "Pam", dateofbirth: new Date("October 23,1981"), gender: 3, salary: 53000 },
    ];

    $scope.employeesToFilter = employeesToFilter;

    $scope.rowLimit = 4;

    $scope.sortColumn = "name";
    $scope.reverseSort = false;

    $scope.sortData = function (column) {
        $scope.reverseSort = ($scope.sortColumn == column) ? !$scope.reverseSort : false;
        $scope.sortColumn = column;
    }

    $scope.ScreenOption = 'EmployeeList.html';

    $scope.message = "AngularJS Tutorial";

    $scope.image = '/Images/pic.jpg'
})